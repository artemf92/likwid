$(document).ready(function(){
  $('.block__our--clients').slick({
    autoplay: true,
    cssEase: 'linear',
    // useCss: true,
    autoplaySpeed: 0,
    speed: 8000,
    variableWidth: true,
    arrows: false,
    pauseOnHover: true,
  });
  $('.block__our--partners').slick({
    rtl: true,
    autoplay: true,
    cssEase: 'linear',
    // useCss: true,
    autoplaySpeed: 0,
    speed: 8000,
    variableWidth: true,
    arrows: false,
    pauseOnHover: true,
  });
  $('.block__mails--wrapper').slick({
    autoplay: true,
    cssEase: 'linear',
    autoplaySpeed: 0,
    speed: 9000,
    variableWidth: true,
    pauseOnHover: true,
  });
});
